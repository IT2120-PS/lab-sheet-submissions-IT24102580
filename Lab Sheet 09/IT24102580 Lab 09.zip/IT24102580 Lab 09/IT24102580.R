setwd("C:/Users/mukad/OneDrive - Sri Lanka Institute of Information Technology/Probablity and Statistics")

#1 meme counts
memes <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)

# H0: μ = 3
# H1: μ ≠ 3 (two-tailed)
t_test_memes <- t.test(memes, mu = 3, alternative = "two.sided")

cat("===== Meme Count Test =====\n")
print(t_test_memes)
cat("Conclusion: At 5% significance, if p-value < 0.05, reject H0.\n\n")

#2 Mouse Weight Test
weights <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)

# H0: μ = 25
# H1: μ < 25 (left-tailed)
t_test_mice <- t.test(weights, mu = 25, alternative = "less")

cat("===== Mouse Weight Test =====\n")
print(t_test_mice)
cat("Test Statistic:", t_test_mice$statistic, "\n")
cat("P-value:", t_test_mice$p.value, "\n")
cat("Confidence Interval:\n")
print(t_test_mice$conf.int)
cat("Conclusion: If p-value < 0.05, reject H0. Mean weight is less than 25g.\n\n")

#3 Cookie Sugar Level Test

set.seed(123)
sugar_levels <- rnorm(30, mean = 9.8, sd = 0.05)

# H0: μ = 9.8
# H1: μ > 10 (right-tailed)
t_test_sugar <- t.test(sugar_levels, mu = 10, alternative = "greater")

cat("===== Cookie Sugar Level Test =====\n")
print(t_test_sugar)
cat("Conclusion: If p-value < 0.05, mean sugar level > 10.\n\n")

#4 Exercise: Cookie Baking Time Test

set.seed(123)
baking_time <- rnorm(25, mean = 45, sd = 2)

# H0: μ = 46
# H1: μ < 46 (left-tailed)
t_test_bake <- t.test(baking_time, mu = 46, alternative = "less")

cat("===== Baking Time Test =====\n")
print(t_test_bake)
cat("Conclusion: If p-value < 0.05, average baking time is significantly less than 46 minutes.\n")
