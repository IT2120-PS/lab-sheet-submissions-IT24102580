# 1. Import the data
setwd("C:\\Users\\mukad\\OneDrive - Sri Lanka Institute of Information Technology\\Probablity and Statistics\\IT24102580 Lab 08")
data_path <- "C:\\Users\\mukad\\OneDrive - Sri Lanka Institute of Information Technology\\Probablity and Statistics\\IT24102580 Lab 08\\Exercise - LaptopsWeights.txt"
laptop_data <- read.table(data_path, header = TRUE)

# View data
print(laptop_data)

# Extract the weights
weights <- laptop_data$Weight.kg.


# 2. Population mean and population standard deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)
cat("Population Mean:", pop_mean, "\n")
cat("Population SD:", pop_sd, "\n")

# 3. Draw 25 random samples of size 6 (with replacement)
set.seed(123)  # for reproducibility

sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample_i <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
}

# Display results
cat("\nSample Means:\n")
print(sample_means)
cat("\nSample SDs:\n")
print(sample_sds)

# 4. Mean and standard deviation of sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", mean_of_sample_means, "\n")
cat("SD of Sample Means:", sd_of_sample_means, "\n")

# 5. Relationship to true mean and true SD
cat("\n--- Relationship ---\n")
cat("The mean of the sample means is approximately equal to the population mean.\n")
cat("The SD of the sample means is smaller than the population SD,\n")
cat("and approximately equal to population SD / sqrt(sample size).\n")

expected_sd_sample_means <- pop_sd / sqrt(6)
cat("Expected SD of Sample Means:", expected_sd_sample_means, "\n")
