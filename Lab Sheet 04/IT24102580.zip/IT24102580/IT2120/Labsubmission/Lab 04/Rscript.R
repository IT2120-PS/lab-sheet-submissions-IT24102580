##Part 1
#Setting Directory
setwd("C:/Users/IT24102580/Desktop/IT24102580/IT2120/Labsubmission/Lab 04")

##Importing the data set
data <- read.table("C:/Users/IT24102580/Desktop/IT24102580/IT2120/Labsubmission/Lab 04/DATA 4.txt", header = TRUE, sep = " ")

#view the file in a separate window
fix(data)

##Attach the file into R. So, you can call the variables by their names.
attach(data)


##Part 2
##Part (a)
#Obtaining Box Plots
boxplot(X1, main = "Box plot for Team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

#Obtaining Histogram
hist(X1, ylab = "Frequency", xlab = "Team Attendance", main = "Histogram for Team Attendance")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

#Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)


##Part (b)
##Mean
mean(X1)
mean(X2)
mean(X3)

##Median
median(X1)
median(X2)
median(X3)

##Standard Deviation
sd(X1)
sd(X2)
sd(X3)


##Part (c)
#Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

#Getting only five number summary for X1 variable
quantile(X1)

#Calling first Quartile of X1 using index value
quantile(X1)[2]

#Calling third Quartile of X1 using index value
quantile(X1)[4]


#pard (d)
#obtaining inter quartaile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)

## Function to get the mode of a data set
get.mode <- function(y) {
  counts <- table(y)  # Create frequency table for the variable
  mode_value <- names(counts[counts == max(counts)])  # Find the mode (most frequent value)
  return(mode_value)  # Return the mode value
}

# Obtaining the mode of a variable using the function defined above
get.mode(X3)

###Explanation on how each command inside the function works
#Following command is to get the frequency table for the variable
table(X3)

#Following command will give the maximum frequency in the frequency table
max(counts)

#Following command will check whether frequencies in the frequency table equals
#to the maximum frequency obtained
counts == max(counts)

#This extracts both value and the frequency which gives 'TRUE' in earlier logical function
counts[counts == max(counts)]

#This extracts the value which gives maximum frequency (mode) in earlier logical function
names(counts[counts == max(counts)])


##Part 4
##Function to check the existence of outliers of a data set
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = " ")))
}

##Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

###Explanation on how each command inside the function works
#Following command is to calculate the interval for outliers
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  #Following command is to display the upper bound and lower bound of the interval
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  #Checking the existence of outliers and Display the outliers if they exist
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = " ")))
}

#Exercise
# Import the dataset 'Exercise.txt' and store it in a data frame 'branch.data'
branch.data <- read.table("C:/Users/IT24102580/Desktop/IT24102580/IT2120/Labsubmission/Lab 04/Exercise.txt", header = TRUE, sep = "\t")

# View the first few rows of the data to ensure it's loaded correctly
head(branch.data)

#2
# Identify the structure of the data to understand variable types
str(branch.data)

# You can also check the summary of each variable
summary(branch.data)

#3
# Create the data frame
data <- data.frame(
  Branch = 1:30,
  Sales_X1 = c(3.4, 4.1, 2.8, 5, 3.7, 4.5, 3, 4.9, 3.2, 2.5, 3.9, 4.2, 2.7, 3.6, 4.8, 3.3, 4, 5.1, 3.8, 2.9, 4.4, 3.1, 4.6, 3.5, 4.3, 3, 4.7, 2.6, 3.9, 4.2),
  Advertising_X2 = c(120, 150, 90, 200, 110, 175, 95, 185, 105, 80, 130, 140, 100, 125, 190, 115, 135, 210, 145, 85, 160, 100, 170, 120, 155, 90, 180, 95, 140, 150),
  Years_X3 = c(4, 7, 3, 10, 5, 6, 2, 9, 4, 1, 5, 7, 3, 4, 8, 5, 6, 12, 6, 2, 9, 3, 10, 5, 8, 2, 11, 1, 6, 7)
)

# Create a boxplot for Sales_X1
boxplot(data$Sales_X1, 
        main = "Boxplot for Sales (X1)", 
        ylab = "Sales", 
        col = "lightblue")

# Optionally, display the summary statistics
summary(data$Sales_X1)

#4
# Assuming 'Advertising' is the name of the advertising variable in the dataset
# Calculate the five-number summary and IQR
summary(branch.data$Advertising)

# To manually calculate IQR
IQR(branch.data$Advertising)

#5
# Function to find outliers using IQR method
find_outliers <- function(x) {
  q1 <- quantile(x)[2]  # First quartile
  q3 <- quantile(x)[4]  # Third quartile
  iqr <- q3 - q1        # Interquartile range
  ub <- q3 + 1.5 * iqr  # Upper bound for outliers
  lb <- q1 - 1.5 * iqr  # Lower bound for outliers
  
  # Identify outliers that are below the lower bound or above the upper bound
  outliers <- x[x < lb | x > ub]
  
  return(outliers)
}

# Assuming 'Years' is the name of the years variable in the dataset
outliers_years <- find_outliers(branch.data$Years)

# Print outliers in 'Years' variable
print(outliers_years)
