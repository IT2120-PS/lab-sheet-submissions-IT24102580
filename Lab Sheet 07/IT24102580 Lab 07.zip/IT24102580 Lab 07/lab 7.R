setwd("C:/Users/mukad/OneDrive - Sri Lanka Institute of Information Technology/Probablity and Statistics/IT24102580 Lab 07")
#Exercise 
#Question 1
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Question 2
pexp(q = 2, rate = 1/3)

#Question 3
#Part1
#pr randomly selected person Iq > 130
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

#par2
#Iq scode reperensetns the 95th percentile
qnorm(0.95, mean = 100, sd = 15)