setwd("C:/Users/mukad/OneDrive - Sri Lanka Institute of Information Technology/Probablity and Statistics/IT24102580 lab 6")

#Exercise
#Question1
#1) Binomial Distribution
#Here , random variable X has Binomial distribution with n = 50 and p = 0.85

#2)
pbinom(46,50,0.85, lower.tail = FALSE)


#Question2
#1) average of 12 customer calls per hour
#2)here ,random variable X has poisson distribution with lambda = 12
#3)
ppois(15,12,lower.tail = FALSE)