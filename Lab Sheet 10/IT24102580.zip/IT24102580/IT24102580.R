setwd("C:/Users/IT24102580/Desktop/IT24102580")
observed <- c(120,95,85,100)
prob<-c (.25, .25, .25, .25) 

#Null hyposthesis = choosing snacks has same probabaiy among customers
#Alternative hypothesis = choosing snacks has different Pr among customers
chisq.test(x=observed, p=prob)

#Conclsion
#Consider 5% level of significance for the test
#Rejection region: If the P value for the test is less than 0.05
#P value : 0.08966


#Conclusion : The value (0.08966) is greater than 0.05-
#Do  not reject null hyposthesis(H0) at alfa = 0.05-
#There fore we can conclude That pr that-
#customers chooing sncakes between(A,B,C,D)-
#Each day will be same which is 0.25-